// Mock Bond Smart Contract for Demo
class NigerianBondContract {
  constructor() {
    this.bonds = new Map();
    this.holders = new Map();
  }

  // Deploy new bond
  deployBond(params) {
    const bond = {
      policyId: `policy_${Date.now()}`,
      issuer: params.issuer,
      series: params.series,
      totalSupply: params.totalSupply,
      faceValue: params.faceValue,
      couponRate: params.couponRate,
      maturityDate: params.maturityDate,
      createdAt: new Date()
    };
    
    this.bonds.set(params.series, bond);
    console.log(`✅ Bond ${params.series} deployed successfully`);
    return bond;
  }

  // Mint tokens to investor
  mintTokens(series, investor, amount) {
    const bond = this.bonds.get(series);
    if (!bond) throw new Error('Bond not found');
    
    // Mock blockchain transaction
    const txHash = `tx_${Math.random().toString(36).substring(2, 15)}`;
    
    // Update holder balance
    const currentBalance = this.holders.get(investor) || 0;
    this.holders.set(investor, currentBalance + amount);
    
    console.log(`✅ Minted ${amount} tokens of ${series} to ${investor}`);
    return {
      txHash,
      bond: series,
      investor,
      amount,
      block: Math.floor(Math.random() * 1000000)
    };
  }

  // Transfer tokens between investors
  transferTokens(from, to, series, amount) {
    const fromBalance = this.holders.get(from) || 0;
    if (fromBalance < amount) throw new Error('Insufficient balance');
    
    const toBalance = this.holders.get(to) || 0;
    
    this.holders.set(from, fromBalance - amount);
    this.holders.set(to, toBalance + amount);
    
    const txHash = `tx_${Math.random().toString(36).substring(2, 15)}`;
    
    console.log(`✅ Transferred ${amount} tokens from ${from} to ${to}`);
    return {
      txHash,
      from,
      to,
      series,
      amount,
      timestamp: new Date()
    };
  }

  // Get investor balance
  getBalance(investor, series) {
    return this.holders.get(investor) || 0;
  }

  // Mock coupon payment
  payCoupon(series) {
    const bond = this.bonds.get(series);
    if (!bond) throw new Error('Bond not found');
    
    const payments = [];
    this.holders.forEach((balance, investor) => {
      if (balance > 0) {
        const interest = balance * (bond.couponRate / 100 / 2); // Semi-annual
        payments.push({
          investor,
          tokens: balance,
          interest: Math.round(interest),
          paymentDate: new Date()
        });
      }
    });
    
    console.log(`✅ Paid coupons for ${series} to ${payments.length} investors`);
    return payments;
  }
}

// Export singleton instance
module.exports = new NigerianBondContract();