const express = require('express');
const cors = require('cors');
const bondContract = require('./contracts/bondContract');
require('dotenv').config();

const app = express();
app.use(cors());
app.use(express.json());

// Deploy demo bonds on startup
bondContract.deployBond({
  issuer: 'DMO_NIGERIA',
  series: 'FGN2027',
  totalSupply: 10000000000,
  faceValue: 1,
  couponRate: 12.0,
  maturityDate: '2027-12-31'
});

bondContract.deployBond({
  issuer: 'DMO_NIGERIA', 
  series: 'FGN2030',
  totalSupply: 5000000000,
  faceValue: 1,
  couponRate: 11.5,
  maturityDate: '2030-06-30'
});

// Mock data
const mockBonds = [
  {
    id: 'FGN2027',
    name: 'FGN 12% 2027 Bond',
    couponRate: 12.0,
    maturity: '2027-12-31',
    available: 5000000000,
    price: 1.00,
    yield: 12.0
  },
  {
    id: 'FGN2030',
    name: 'FGN 11.5% 2030 Bond', 
    couponRate: 11.5,
    maturity: '2030-06-30',
    available: 3000000000,
    price: 1.02,
    yield: 11.3
  }
];

let mockInvestors = [
  {
    id: '1',
    name: 'Ada Okafor',
    bvn: '12345678901',
    tier: 1,
    walletAddress: 'addr_test1qzkzy66example',
    portfolio: [
      { bondId: 'FGN2027', tokens: 50000, value: 50000 }
    ]
  }
];

// ==================== API ENDPOINTS ====================

// 1. Get all bonds
app.get('/api/bonds', (req, res) => {
  res.json({
    success: true,
    bonds: mockBonds,
    timestamp: new Date().toISOString()
  });
});

// 2. Onboard new investor
app.post('/api/investor/onboard', (req, res) => {
  const { name, bvn, phone } = req.body;
  
  // Mock KYC verification
  const newInvestor = {
    id: (mockInvestors.length + 1).toString(),
    name,
    bvn,
    phone,
    tier: 1,
    walletAddress: `addr_test${Math.random().toString(36).substring(7)}`,
    cscsAccount: `CSCS${Math.random().toString(36).substring(2, 10).toUpperCase()}`,
    portfolio: [],
    onboardedAt: new Date().toISOString()
  };
  
  mockInvestors.push(newInvestor);
  
  res.json({
    success: true,
    message: 'Investor onboarded successfully',
    investor: newInvestor
  });
});

// 3. Purchase bonds
app.post('/api/bonds/purchase', (req, res) => {
  const { investorId, bondId, amount } = req.body;
  
  const investor = mockInvestors.find(inv => inv.id === investorId);
  const bond = mockBonds.find(b => b.id === bondId);
  
  if (!investor || !bond) {
    return res.status(404).json({ error: 'Investor or bond not found' });
  }
  
  try {
    // 1. Mint tokens on blockchain
    const blockchainTx = bondContract.mintTokens(bondId, investor.walletAddress, amount);
    
    // 2. Update local portfolio
    const existingHolding = investor.portfolio.find(p => p.bondId === bondId);
    if (existingHolding) {
      existingHolding.tokens += amount;
      existingHolding.value += amount * bond.price;
    } else {
      investor.portfolio.push({
        bondId,
        tokens: amount,
        value: amount * bond.price,
        purchaseDate: new Date().toISOString()
      });
    }
    
    bond.available -= amount;
    
    res.json({
      success: true,
      message: `Purchased ${amount} tokens of ${bond.name}`,
      transactionId: blockchainTx.txHash,
      blockchain: {
        txHash: blockchainTx.txHash,
        block: blockchainTx.block,
        timestamp: new Date().toISOString()
      },
      portfolio: investor.portfolio
    });
    
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// 4. Get investor portfolio
app.get('/api/investor/:id/portfolio', (req, res) => {
  const investor = mockInvestors.find(inv => inv.id === req.params.id);
  if (!investor) {
    return res.status(404).json({ error: 'Investor not found' });
  }
  
  const portfolioValue = investor.portfolio.reduce((total, holding) => total + holding.value, 0);
  
  res.json({
    success: true,
    portfolio: investor.portfolio,
    totalValue: portfolioValue,
    investor: {
      name: investor.name,
      tier: investor.tier,
      walletAddress: investor.walletAddress
    }
  });
});

// 5. DMO Dashboard - THIS WAS MISSING!
app.get('/api/dmo/dashboard', (req, res) => {
  const totalIssued = mockBonds.reduce((sum, bond) => sum + ((bond.totalSupply - bond.available) * bond.price), 0);
  const investorCount = mockInvestors.length;
  
  // Calculate recent activity
  const recentActivity = [];
  mockInvestors.forEach(investor => {
    investor.portfolio.forEach(holding => {
      recentActivity.push({
        type: 'PURCHASE',
        investor: investor.name,
        bond: holding.bondId,
        amount: holding.tokens,
        timestamp: holding.purchaseDate || new Date().toISOString()
      });
    });
  });
  
  res.json({
    success: true,
    dashboard: {
      totalBondsIssued: totalIssued,
      activeInvestors: investorCount,
      averageInvestment: totalIssued / investorCount || 0,
      bonds: mockBonds.map(bond => ({
        ...bond,
        investors: Math.floor(Math.random() * 1000) + 100 // Mock data
      })),
      recentActivity: recentActivity.slice(0, 5) // Last 5 activities
    }
  });
});

// 6. Blockchain endpoints
app.get('/api/blockchain/bonds', (req, res) => {
  res.json({
    success: true,
    deployedBonds: Array.from(bondContract.bonds.entries()).map(([series, bond]) => ({
      series: bond.series,
      totalSupply: bond.totalSupply,
      couponRate: bond.couponRate,
      maturityDate: bond.maturityDate,
      policyId: bond.policyId
    }))
  });
});

app.post('/api/blockchain/mint', (req, res) => {
  const { investor, bondSeries, amount } = req.body;
  
  try {
    const result = bondContract.mintTokens(bondSeries, investor, amount);
    res.json({
      success: true,
      message: 'Tokens minted on blockchain',
      transaction: result
    });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get('/api/blockchain/balance/:investor', (req, res) => {
  const balances = {};
  mockBonds.forEach(bond => {
    balances[bond.id] = bondContract.getBalance(req.params.investor, bond.id);
  });
  
  res.json({
    success: true,
    investor: req.params.investor,
    blockchainBalances: balances
  });
});

// 7. Get all investors
app.get('/api/investors', (req, res) => {
  res.json({
    success: true,
    investors: mockInvestors.map(inv => ({
      id: inv.id,
      name: inv.name,
      tier: inv.tier,
      walletAddress: inv.walletAddress
    }))
  });
});

// 8. Home route
app.get('/', (req, res) => {
  res.json({
    message: '🇳🇬 Nigerian Bond Tokenization Platform API',
    endpoints: {
      bonds: '/api/bonds',
      dashboard: '/api/dmo/dashboard', 
      investors: '/api/investors',
      blockchain: '/api/blockchain/bonds'
    },
    timestamp: new Date().toISOString()
  });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`🚀 Nigerian Bond Platform API running on port ${PORT}`);
  console.log(`📊 Demo Dashboard: http://localhost:${PORT}/api/dmo/dashboard`);
  console.log(`🔗 Blockchain Bonds: http://localhost:${PORT}/api/blockchain/bonds`);
  console.log(`💸 Bonds Available: http://localhost:${PORT}/api/bonds`);
  console.log(`👥 Investors: http://localhost:${PORT}/api/investors`);
  console.log(`🏠 Home: http://localhost:${PORT}/`);
});